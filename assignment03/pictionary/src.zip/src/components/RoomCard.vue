<template>
        <p class="title">{{ room.name }}</p>
        <p>Players:{{ room.members.length }} / {{ room.maxPlayers }}</p>
        <p>Status:{{ statusText(room.state) }}</p>
        <div class="actions">
          <button class="nes-btn is-success">
            Enter 
          </button>
        </div>
</template>

<script setup>
    const statusText = (status) => {
        let text = "Known"
        switch(status){
            case 0 : text = 'Closed'
            case 1 : text = 'Waiting'
            case 2 : text = 'OnGoing'
        }
        return text
    }
    const props = defineProps({room: {type:Object, required:true}})
</script>