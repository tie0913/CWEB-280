<script setup>
import Header from './components/Header.vue'
import Frame from './components/Frame.vue'

</script>

<template>
  <div class="app-root d-flex flex-column min-vh-100">
    <Header />
    <Frame />
  </div>
 
</template>
